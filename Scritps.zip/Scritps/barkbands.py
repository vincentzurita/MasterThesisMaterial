from essentia.standard import *
import numpy as np
import matplotlib.pyplot as plt
from scipy.io.wavfile import write
import cPickle


rate=44100

w = Windowing(type = 'hann')
beatmulti = BeatTrackerMultiFeature()
beatdega=BeatTrackerDegara()
barkbands=BarkBands()
spectrum = Spectrum()
########READ FILE##################

loader = essentia.standard.MonoLoader(filename = '/home/giuseppe/Dropbox/UPF - sMC/Essential mixes/2015.02.28 - Essential Mix - Max Cooper.mp3')

audio = loader() #load song

#####CUT EVERY 10 SECONDS########
number_of_blocks=len(audio)/(44100*10) 
#last_block=len(audio)%(44100*10)
audio1=[]

barkbands_mean=[]


for i in range(number_of_blocks): 
	print i
	baba=np.ndarray(shape=(44100*10))

	baba=audio[i*44100*10:(i+1)*10*44100]



	bands1=[]
	for frame in FrameGenerator(baba, frameSize = 1024, hopSize = 512):
	 	bands=barkbands(spectrum(w(frame)))

		bands1.append(bands)
	barkbands_mean.append(np.mean(bands1,axis=0))
#mfcc_mean=np.vstack(mfcc_mean)

barkbands_mean=np.array(barkbands_mean)



np.savetxt("MaxCooperbarkbands.csv",barkbands_mean,delimiter=",", fmt="%f")
#np.savetxt("bands1.csv",bands1,delimiter=",", fmt="%f")
# np.save(bands1,mfcc1)
# np.savetxt("mfcctest.csv",zip(float(items) for items in mfcc1),delimiter=",", fmt="%f")