from essentia.standard import *
import numpy as np
import matplotlib.pyplot as plt
from scipy.io.wavfile import write
import cPickle


rate=44100

w = Windowing(type = 'hann')


beatmulti = BeatTrackerMultiFeature()
beatdega=BeatTrackerDegara()
flux=Flux()
LP=LowPass(cutoffFrequency=1000) 
HP=HighPass(cutoffFrequency=1000)
spectrum = Spectrum()
loudness = Loudness()
energy=Energy()
rms=RMS()
centroid= Centroid()
pitchsalience=PitchSalience()



########READ FILE##################

loader = essentia.standard.MonoLoader(filename = '/home/giuseppe/Dropbox/UPF - sMC/Essential mixes/2015.02.28 - Essential Mix - Max Cooper.mp3')

audio = loader() #load song

#####CUT EVERY 10 SECONDS########
number_of_blocks=len(audio)/(44100*10) 
#last_block=len(audio)%(44100*10)
audio1=[]

# number_of_blocks_two=len(audio)/(44100*10)
# #last_block_two=len(audio)%(44100*10)
# audio2=[]


def find_bpm(beaters): #For now calculates BPM using difference between beats method, might be changed later
	b=[t - s for s, t in zip(beaters, beaters[1:])]
	c=np.mean(b)
  	return 60/c

def moving_average(a, n=5) :
    ret = np.cumsum(a, dtype=float)
    ret[n:] = ret[n:] - ret[:-n]
    return ret[n - 1:] / n	

def get_beats(audio,beats_time_multi):
	beats=[]
	bars=[]
	for i in range(len(beat_time_multi)-1): #Get the beats of the song in an array
		beats.append(audio[beat_time_multi[i]*rate:beat_time_multi[i+1]*rate])
	for i in range(int(len(beats)/4)-4):
	    bars.append(beats[i*4:i*4+4])
	return beats,bars 	



bpms=[]
loudness_mean=[]
loudness_std=[]	
energy_mean=[]
energy_std=[]
rms_mean=[]
rms_std=[]
centroid_mean=[]
centroid_std=[]
barkbands_mean=[]
onsets10=[]
pitchsalience_mean=[]
pitchsalience_std=[]
danceability_mean=[]


for i in range(number_of_blocks): 
	print i
	onsetrate=OnsetRate()
	danceabilityrate=Danceability()



	baba=np.ndarray(shape=(44100*10))
	baba=audio[i*44100*10:(i+1)*10*44100]

	beatmulti = BeatTrackerMultiFeature()
	beat_time_multi,beat_conf_multi=beatmulti(baba)
	beatpm=find_bpm(beat_time_multi) 
	bpms.append(beatpm)




	loudnes1=[]
	energy1=[]
	rms1=[] 
	centroid1=[]
	pitchsalience1=[]


	for frame in FrameGenerator(baba, frameSize = 1024, hopSize = 512):
		loudnes=loudness(spectrum(w(frame)))
		loudnes1.append(loudnes)
		energyy=energy(spectrum(w(frame)))
		energy1.append(energyy)
		rmss=rms(spectrum(w(frame)))
		rms1.append(rmss)
		centroidd=centroid(spectrum(w(frame)))
		centroid1.append(centroidd)
		pitchsaliencee=pitchsalience(spectrum(w(frame)))
		pitchsalience1.append(pitchsaliencee)




	loudnes1=np.vstack(loudnes1)
	loudness_mean.append(np.mean(loudnes1))
	loudness_std.append(np.std(loudnes1))
	energy1=np.vstack(energy1)
	energy_mean.append(np.mean(energy1))
	energy_std.append(np.std(energy1))
	rms1=np.vstack(rms1)
	rms_mean.append(np.mean(rms1))
	rms_std.append(np.std(rms1))
	centroid1=np.vstack(centroid1)
	centroid_mean.append(np.mean(centroid1))
	centroid_std.append(np.std(centroid1))
	pitchsalience_mean.append(np.mean(pitchsalience1))
	pitchsalience_std.append(np.std(pitchsalience1))


	onset_time,onset_rate=onsetrate(baba)
	onsets10.append(onset_rate)
	danceability=danceabilityrate(baba)
	danceability_mean.append(danceability)




# bp=moving_average(bpms)
# loudness_mean=np.array(loudness_mean)
# loudness_std=np.array(loudness_std)
# loudness_mean_average=moving_average(loudness_mean)
# loudness_std_average=moving_average(loudness_std)
# energy_mean=np.array(energy_mean)
# energy_std=np.array(energy_std)
# energy_mean_average=moving_average(energy_mean)
# energy_std_average=moving_average(energy_std)
# rms_mean=np.array(rms_mean)
# rms_std=np.array(rms_std)
# rms_mean_average=moving_average(rms_mean)
# rms_std_average=moving_average(rms_std)

# #####save RESULTS IN CSV FILE################
np.savetxt("MaxCooperDescriptors.csv",zip(bpms,rms_mean,rms_std,energy_mean,energy_std,loudness_mean,loudness_std,onsets10,centroid_mean,centroid_std,pitchsalience_mean,pitchsalience_std,danceability_mean),delimiter=",", fmt="%f")
#np.savetxt("barkbands.csv",zip(barkbands1),delimiter=",", fmt="%f")
#np.savetxt(".csv",zip(onsets5),delimiter=",", fmt="%f")

###average
#np.savetxt("resultsaveragemaxcooper2.csv",zip(bp,rms_mean_average,rms_std_average,energy_mean_average,energy_std_average,loudness_mean_average,loudness_std_average),delimiter=",", fmt="%f")
